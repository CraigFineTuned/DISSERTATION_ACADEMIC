# RICHFIELD DISSERTATION REQUIREMENTS MATRIX
**Source Documents:**
- Supervisor Transcript (03/11/2025)
- Sample Dissertation (IoT-based Smart Cities - Richfield BSc Honours)

**Extracted:** November 15, 2025  
**For:** Craig Vraagom - UGENTIC Dissertation

---

## 📋 CRITICAL STRUCTURAL REQUIREMENTS

### **MANDATORY STRUCTURE**
| Element | Requirement | Status Check |
|---------|-------------|--------------|
| **Total Chapters** | EXACTLY 5 chapters (NOT 6 or 7) | ⚠️ VERIFY |
| **Page Count** | 80-120 pages (strict limits) | ⚠️ COUNT NEEDED |
| **Cover Page** | Richfield logo + "partial fulfillment" language | ⚠️ CREATE |
| **Preliminary Pages** | Declaration → Acknowledgements → Abstract → TOC | ⚠️ VERIFY ORDER |
| **Appendices** | Samples ONLY (max 1 page per item) | ⚠️ LIMIT |

### **CITATION REQUIREMENTS**
| Rule | Specification | Compliance |
|------|---------------|------------|
| **Recency** | ALL citations 2020-2025 (5-year max) | ⚠️ VERIFY ALL |
| **Frequency** | Max 2 lines without citation (Intro, Lit Review) | ⚠️ CHECK |
| **Prohibited Locations** | NO citations in: Objectives, Questions, Aim | ⚠️ REMOVE IF PRESENT |
| **Required Locations** | Citations IN: Background, Introduction, Significance | ✅ EXPECTED |
| **Style** | Harvard referencing (consistent) | ⚠️ VERIFY |

---

## 📖 CHAPTER-BY-CHAPTER REQUIREMENTS

### **CHAPTER 1: INTRODUCTION**

#### **Section Order (MANDATORY)**
1. **Background** (MUST be first section)
   - Historical context
   - Status quo
   - Broader landscape
   - Citations REQUIRED

2. **Introduction**
   - Topic introduction
   - Scope and boundaries
   - Focus statement
   - Link to background
   - Citations REQUIRED

3. **Aim**
   - **ONE statement ONLY**
   - Format: "The aim of this research is to [verb]..."
   - **NO explanation**
   - **NO paragraphs**
   - **NO citations**

4. **Objectives**
   - **3-5 objectives** (NOT less than 3, NOT more than 5)
   - High-level, rigorous, broad
   - Encapsulate entire research
   - **NO citations**
   - **NO explanations**

5. **Research Questions**
   - **3-5 questions** (MUST match number of objectives)
   - One question per objective (direct alignment)
   - High-level, researchable, specific
   - **NOT operational questions from questionnaire**
   - **NO citations**

6. **Significance of Study**
   - Why research is important
   - Relevance to field
   - Potential impact
   - Contribution to knowledge
   - **Citations REQUIRED** (well-supported arguments)

7. **Structure of Dissertation**
   - **ONE paragraph ONLY**
   - At END of Chapter 1
   - Start with Chapter 2 (reader already in Ch 1)
   - Brief, concise description per chapter
   - Format: "Chapter 2 is literature review covering... Chapter 3 is..."

8. **Conclusion**
   - Summarize key points from Chapter 1
   - **NO new information**
   - Reiterate significance

---

### **CHAPTER 2: LITERATURE REVIEW**

#### **Structure**
- **Thematic approach** (identify major themes/motifs)
- **Critical review** (NOT summary, NOT explanation)
- **Gap identification** (explicit gaps in literature)

#### **Critical Requirements**
| Requirement | Details |
|-------------|---------|
| **Approach** | Analytical, critical - bring different ideas together |
| **DO NOT** | Explain concepts, summarize information |
| **DO** | Critique existing literature, identify gaps, synthesize |
| **Theme Labels** | DO NOT use word "theme" - use actual theme name |
| **Citations** | MANY citations required (most cited chapter) |
| **Introduction** | Brief overview of chapter |
| **Conclusion** | Mandatory - summarize key findings and gaps |

#### **Content Pattern**
```
Introduction
Theme 1: [Actual Theme Name]
  - Examine different perspectives
  - Highlight methodologies
  - Express trends, patterns
  - Identify controversies
  
Theme 2: [Actual Theme Name]
  - [Same pattern]

Theme N: [Actual Theme Name]
  - [Same pattern]

Conclusion
```

---

### **CHAPTER 3: PROBLEM STATEMENT**

#### **Options**
- **Option A:** Standalone chapter (PREFERRED by supervisor)
- **Option B:** Combined with Chapter 1 (ACCEPTABLE)

#### **Requirements**
| Element | Specification |
|---------|---------------|
| **Introduction** | Brief overview |
| **Problem Definition** | Specific issue/challenge addressed |
| **Problem Detail** | What makes it a problem, who it affects, why unresolved |
| **Gap Linkage** | Connect to Literature Review gaps |
| **Case Building** | WHY investigation needed |
| **Contribution** | How research solves/understands problem |
| **Citations** | Well-supported with literature |
| **Conclusion** | Mandatory |

---

### **CHAPTER 4: METHODOLOGY**

#### **Language Requirement**
- **PAST TENSE** (research already completed)
- Report on what WAS done, not what WILL be done

#### **Sections**
1. **Introduction/Background**
   - Context and foundation
   - Overarching research design

2. **Research Design**
   - Quantitative/Qualitative/Mixed methods
   - Framework underpinning research

3. **Reliability and Validity**
   - Measures taken to ensure consistency and accuracy

4. **Target Population**
   - Who was studied

5. **Population Sample**
   - Sampling method and size

6. **Data Collection Instruments**
   - Tools used (questionnaires, interviews, etc.)
   - Past tense description

7. **Data Analysis**
   - Methods used for analysis

8. **Ethical Considerations**
   - Ethics approval, consent, confidentiality

9. **Limitations**
   - Study limitations

10. **Summary/Conclusion**
    - Mandatory

---

### **CHAPTER 5: RESULTS**

#### **Critical Requirements**
| Requirement | Specification | Priority |
|-------------|---------------|----------|
| **MINIMUM GRAPHS** | 3 graphs MANDATORY | 🔴 CRITICAL |
| **Visual Representation** | Cannot have only tables | 🔴 CRITICAL |
| **Graph Interpretation** | Detailed interpretation of EACH graph | 🔴 CRITICAL |
| **Objective Linkage** | Link results to objectives and questions | 🔴 CRITICAL |

#### **Structure**
1. **Introduction/Overview**
   - Context of results
   - Purpose of presenting results

2. **Response Rate/Data Collection Process**
   - Participants involved
   - Methods used
   - Relevant feedback highlights

3. **Results Presentation**
   - **MINIMUM 3 graphs**
   - Tables (if needed, but graphs are MANDATORY)
   - Interpret each graph in detail:
     * What does each line/bar represent?
     * What do the numbers mean?
     * What's on X-axis? Y-axis?
     * Why these values?

4. **Patterns and Trends**
   - Highlight prominent patterns
   - Identify significant results
   - Discuss trends observed

5. **Linkage to Research Framework**
   - Connect to objectives
   - Connect to research questions
   - Ensure logical flow and coherence

6. **Conclusion**
   - Summarize main findings
   - Mandatory section

---

### **CHAPTER 6: DISCUSSION AND CONCLUSION**

#### **Purpose**
- Recap ENTIRE dissertation
- Highlight contributions
- NO new information

#### **Structure**
1. **Introduction**
   - High-level overview of research journey

2. **Research Overview**
   - Problem addressed
   - Methodology used
   - Key findings
   - Overall contributions

3. **Key Results**
   - Principal outcomes from data analysis
   - Major discoveries
   - **Concise manner** (no long stories)

4. **Contributions**
   - Novel insights
   - Significance of research
   - Impact on body of knowledge

5. **Recommendations**
   - Practical implications
   - Policy recommendations
   - Future applications

6. **Future Research**
   - Areas for further investigation
   - Unanswered questions

7. **Conclusion**
   - Final summary
   - **NO new information introduced**

---

## 📏 FORMATTING REQUIREMENTS

### **General**
| Element | Specification |
|---------|---------------|
| **Page Numbers** | All pages numbered |
| **Headers/Footers** | As per Richfield standards |
| **Font** | [Check Richfield guidelines] |
| **Line Spacing** | [Check Richfield guidelines] |
| **Margins** | [Check Richfield guidelines] |

### **Appendices**
| Rule | Specification |
|------|---------------|
| **Content** | Samples ONLY (not raw data) |
| **Length** | Max 1 page per item |
| **Examples** | - Code: 0.5 page snippet<br>- Questionnaire: 0.5-1 page sample<br>- Ethics: 1 page |
| **Purpose** | "For your information" - NOT counted in page total |
| **NOT Allowed** | - Full datasets<br>- 10 pages of code<br>- Complete questionnaires |

---

## ⚠️ COMMON MISTAKES TO AVOID

### **From Supervisor Transcript**
1. ❌ **Mixing proposal and dissertation language**
   - "I'm going to do" → "The research DID"
   - "I will collect" → "Data WAS collected"

2. ❌ **Incorrect chapter ordering**
   - Objectives BEFORE questions (not reversed)
   - Background BEFORE introduction

3. ❌ **Aim errors**
   - Multiple aim statements
   - Paragraphs explaining aim
   - Citations in aim

4. ❌ **Question/Objective mismatch**
   - Different number of objectives vs questions
   - No direct correspondence

5. ❌ **Literature review as summary**
   - Explaining concepts instead of critiquing
   - Missing gap identification
   - Using "Theme 1, Theme 2" labels

6. ❌ **Introduction of new content in conclusion**
   - New discoveries in Ch 6 conclusion
   - Information not discussed in body

7. ❌ **Structure of dissertation**
   - 2-3 pages explaining each chapter
   - Including Chapter 1 in the structure section

8. ❌ **Results without graphs**
   - Only tables, no visual representations
   - Less than 3 graphs

9. ❌ **Old references**
   - Citations older than 5 years
   - Dated references making work seem outdated

10. ❌ **Massive appendices**
    - 10 pages of code
    - Complete raw data dumps

---

## 🎯 SAMPLE DISSERTATION STRUCTURE OBSERVED

### **From IoT Smart Cities Sample**
```
Cover Page
Acknowledgements
Declaration
Abstract (246 words in sample - concise!)
Table of Contents
List of Tables
List of Figures
List of Abbreviations
Key Terms

Chapter 1: Introduction (13 pages)
Chapter 2: Literature Review (31 pages)
Chapter 3: Research Problem (2 pages - very short!)
Chapter 4: Methodology (17 pages)
Chapter 5: Data Analysis and Presentation (55 pages)
Chapter 6: Summary and Recommendations (4 pages)

References
Appendix (Ethical Clearance Letter only)
```

**Total Structure:** 6 chapters in sample
⚠️ **NOTE:** Supervisor said 5 chapters preferred, but sample has 6
**RESOLUTION:** Ch 3 can be merged with Ch 1 → 5 chapters

---

## ✅ COMPLIANCE CHECKLIST

### **Pre-Submission Verification**

#### **Structure**
- [ ] Exactly 5 chapters (or 6 if Problem Statement separate)
- [ ] 80-120 pages total
- [ ] Cover page with Richfield logo
- [ ] All preliminary pages in correct order
- [ ] Appendices limited to samples (max 1 page each)

#### **Chapter 1**
- [ ] Background is FIRST section
- [ ] Aim is ONE statement with NO explanation
- [ ] 3-5 objectives (NO citations)
- [ ] 3-5 questions matching objectives (NO citations)
- [ ] Structure of dissertation is ONE paragraph at END
- [ ] NO citations in aim, objectives, questions
- [ ] Citations in background, introduction, significance

#### **Chapter 2**
- [ ] Thematic approach used
- [ ] Critical analysis (not summary)
- [ ] Gaps identified explicitly
- [ ] MANY citations throughout
- [ ] NO use of "Theme 1, Theme 2" labels
- [ ] Introduction and Conclusion present

#### **Chapter 4**
- [ ] ALL descriptions in PAST TENSE
- [ ] NO future tense or proposal language

#### **Chapter 5**
- [ ] MINIMUM 3 graphs present
- [ ] Each graph interpreted in DETAIL
- [ ] Results linked to objectives and questions
- [ ] Patterns and trends highlighted

#### **Chapter 6**
- [ ] NO new information introduced
- [ ] Comprehensive recap of journey
- [ ] Contributions clearly stated
- [ ] Future research suggested

#### **Citations**
- [ ] ALL citations 2020-2025 (5-year limit)
- [ ] Harvard style consistent throughout
- [ ] NO citations older than 5 years
- [ ] Proper citation frequency (max 2 lines without)

#### **Formatting**
- [ ] Page numbers on all pages
- [ ] Headers/footers as required
- [ ] Consistent formatting throughout

---

## 📊 RICHFIELD VS CRAIG'S CURRENT STATUS

### **What Craig Has (5 Chapters)**
1. Chapter 1: Introduction ✅
2. Chapter 2: Literature Review ✅
3. Chapter 3: Methodology ✅
4. Chapter 4: Results ✅
5. Chapter 5: Discussion & Conclusion ✅

### **Richfield Requirement**
**EXACTLY SAME!** ✅

Craig's structure MATCHES Richfield requirement perfectly!

### **Key Verification Needed**
1. ⚠️ Chapter 1 structure (Background first? Aim format? Objectives/Questions count?)
2. ⚠️ All citations 2020-2025? (CRITICAL)
3. ⚠️ Chapter 4 (Results) has minimum 3 graphs?
4. ⚠️ Appendices limited to samples?
5. ⚠️ Total page count 80-120?

---

## 🎯 NEXT ACTIONS (SESSION 62)

1. **Read Craig's Current Chapters 1-5**
2. **Verify Against This Matrix**
3. **Identify Gaps/Non-Compliance**
4. **Create Correction Action Plan**

---

**END OF REQUIREMENT MATRIX**
**Status:** COMPREHENSIVE EXTRACTION COMPLETE ✅
